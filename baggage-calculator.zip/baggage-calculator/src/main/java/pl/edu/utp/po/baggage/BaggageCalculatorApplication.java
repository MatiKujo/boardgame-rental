package pl.edu.utp.po.baggage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punkt startowy aplikacji.
 *
 * Uruchomienie:
 *   - IntelliJ/Eclipse: prawy klik na tę klasę -> Run
 *   - terminal: mvn spring-boot:run
 *
 * Po starcie wejdź na:
 *   http://localhost:8080/checkin         -> odprawa online (formularz bagażu)
 *   http://localhost:8080/swagger-ui.html -> dokumentacja REST API
 *   http://localhost:8080/h2-console      -> podgląd bazy (JDBC URL: jdbc:h2:mem:baggagedb)
 */
@SpringBootApplication
public class BaggageCalculatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(BaggageCalculatorApplication.class, args);
    }
}

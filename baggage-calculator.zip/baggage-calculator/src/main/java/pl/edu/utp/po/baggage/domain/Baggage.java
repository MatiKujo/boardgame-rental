package pl.edu.utp.po.baggage.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.math.BigDecimal;

/**
 * Encja "Bagaż" z treści zadania: waga oraz wymiary X/Y/Z.
 *
 * Jeden wiersz tej tabeli reprezentuje JEDNĄ rezerwację (bilet) - stąd pole
 * reservationNumber. To właśnie ten numer pełni rolę "loginu" klienta
 * (patrz treść zadania: "Klient uwierzytelniony po numerze rezerwacji/ID") -
 * klient nie ma żadnego hasła, po prostu musi znać SWÓJ numer rezerwacji,
 * żeby móc dokonać odprawy online (patrz BaggageService.checkInBaggage).
 *
 * Dopóki klient nie zrobi odprawy online, pola weightKg/dimX/dimY/dimZ są NULL
 * (rezerwacja istnieje, ale bagaż nie został jeszcze "zgłoszony").
 */
@Entity
@Table(name = "baggage")
public class Baggage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flight_id", nullable = false)
    private Flight flight;

    // Numer rezerwacji - unikalny identyfikator biletu, pełni rolę "loginu" klienta.
    @Column(name = "reservation_number", nullable = false, unique = true)
    private String reservationNumber;

    // Waga bagażu w kg - null, dopóki klient nie zrobi odprawy online.
    @Column(name = "weight_kg")
    private BigDecimal weightKg;

    // Wymiary bagażu w centymetrach - również null przed odprawą.
    @Column(name = "dim_x")
    private Integer dimX;

    @Column(name = "dim_y")
    private Integer dimY;

    @Column(name = "dim_z")
    private Integer dimZ;

    // Wynik walidacji gabarytów (czy bagaż mieści się w limicie objętości) - null przed odprawą.
    @Column(name = "volume_valid")
    private Boolean volumeValid;

    // Wyliczona dopłata za nadbagaż (0.00, jeśli mieści się w limicie wagowym) - null przed odprawą.
    @Column(name = "overweight_fee")
    private BigDecimal overweightFee;

    public Baggage() {
    }

    public Baggage(Flight flight, String reservationNumber) {
        this.flight = flight;
        this.reservationNumber = reservationNumber;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public String getReservationNumber() {
        return reservationNumber;
    }

    public void setReservationNumber(String reservationNumber) {
        this.reservationNumber = reservationNumber;
    }

    public BigDecimal getWeightKg() {
        return weightKg;
    }

    public void setWeightKg(BigDecimal weightKg) {
        this.weightKg = weightKg;
    }

    public Integer getDimX() {
        return dimX;
    }

    public void setDimX(Integer dimX) {
        this.dimX = dimX;
    }

    public Integer getDimY() {
        return dimY;
    }

    public void setDimY(Integer dimY) {
        this.dimY = dimY;
    }

    public Integer getDimZ() {
        return dimZ;
    }

    public void setDimZ(Integer dimZ) {
        this.dimZ = dimZ;
    }

    public Boolean getVolumeValid() {
        return volumeValid;
    }

    public void setVolumeValid(Boolean volumeValid) {
        this.volumeValid = volumeValid;
    }

    public BigDecimal getOverweightFee() {
        return overweightFee;
    }

    public void setOverweightFee(BigDecimal overweightFee) {
        this.overweightFee = overweightFee;
    }

    /** Czy klient zrobił już odprawę online (podał wagę i wymiary)? */
    public boolean isCheckedIn() {
        return weightKg != null;
    }
}

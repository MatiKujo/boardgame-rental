package pl.edu.utp.po.baggage.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.edu.utp.po.baggage.domain.Flight;

public interface FlightRepository extends JpaRepository<Flight, Long> {
}

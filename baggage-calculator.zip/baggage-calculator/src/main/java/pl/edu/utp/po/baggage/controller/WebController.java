package pl.edu.utp.po.baggage.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import pl.edu.utp.po.baggage.dto.BaggageCheckRequest;
import pl.edu.utp.po.baggage.service.BaggageService;

import java.util.NoSuchElementException;

/**
 * Kontroler MVC (widoki HTML renderowane przez Thymeleaf).
 *
 * Strony /checkin są PUBLICZNE (patrz SecurityConfig) - klient nie loguje się
 * przez Spring Security, tylko podaje numer rezerwacji w formularzu (patrz
 * BaggageService.checkInBaggage - tam odbywa się właściwe "uwierzytelnienie").
 */
@Controller
public class WebController {

    private final BaggageService baggageService;

    public WebController(BaggageService baggageService) {
        this.baggageService = baggageService;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/checkin";
    }

    /** GET /checkin -> formularz odprawy online (waga + wymiary + numer rezerwacji). */
    @GetMapping("/checkin")
    public String showCheckinForm(Model model) {
        if (!model.containsAttribute("baggageCheckRequest")) {
            model.addAttribute("baggageCheckRequest", new BaggageCheckRequest());
        }
        return "checkin"; // -> templates/checkin.html
    }

    /**
     * POST /checkin
     * GŁÓWNY widok wymagany w treści zadania: "Widok odprawy online – wprowadzanie
     * wymiarów i wagi bagażu dla biletu". Wynik (dopłata / komunikat o gabarytach)
     * pokazujemy na tej samej stronie po przekierowaniu (flash attribute).
     */
    @PostMapping("/checkin")
    public String submitCheckin(@Valid @ModelAttribute("baggageCheckRequest") BaggageCheckRequest request,
                                 BindingResult bindingResult,
                                 RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.baggageCheckRequest", bindingResult);
            redirectAttributes.addFlashAttribute("baggageCheckRequest", request);
            return "redirect:/checkin";
        }

        try {
            var result = baggageService.checkInBaggage(request);
            redirectAttributes.addFlashAttribute("result", result);
        } catch (NoSuchElementException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", "Błąd: " + ex.getMessage());
        }

        return "redirect:/checkin";
    }

    /**
     * GET /employee/flights
     * Panel pracownika - lista lotów do wyboru. Dostęp wymuszony w SecurityConfig
     * ("/employee/**" -> hasRole("EMPLOYEE")).
     */
    @GetMapping("/employee/flights")
    public String showFlights(Model model) {
        model.addAttribute("flights", baggageService.getAllFlights());
        return "employee-flights"; // -> templates/employee-flights.html
    }

    /** GET /employee/flights/{id}/baggage -> lista wszystkich bagaży (rezerwacji) danego lotu. */
    @GetMapping("/employee/flights/{id}/baggage")
    public String showBaggageForFlight(@PathVariable("id") Long flightId, Model model) {
        model.addAttribute("flight", baggageService.getFlightOrThrow(flightId));
        model.addAttribute("baggageList", baggageService.getBaggageForFlight(flightId));
        return "employee-baggage"; // -> templates/employee-baggage.html
    }
}

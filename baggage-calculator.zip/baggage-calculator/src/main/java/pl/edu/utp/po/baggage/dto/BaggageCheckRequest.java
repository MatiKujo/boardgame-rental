package pl.edu.utp.po.baggage.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * DTO danych wprowadzanych przez klienta w formularzu odprawy online
 * (albo przesyłanych do REST endpointu POST /api/baggage/check).
 *
 * Pole reservationNumber pełni rolę "loginu" klienta - patrz komentarz
 * w encji Baggage i w BaggageService.checkInBaggage.
 */
public class BaggageCheckRequest {

    @NotBlank(message = "Podaj numer rezerwacji")
    private String reservationNumber;

    @NotNull(message = "Podaj wagę bagażu")
    @DecimalMin(value = "0.1", message = "Waga musi być większa od zera")
    private BigDecimal weightKg;

    @NotNull(message = "Podaj wymiar X (cm)")
    @Min(value = 1, message = "Wymiar X musi być większy od zera")
    private Integer dimX;

    @NotNull(message = "Podaj wymiar Y (cm)")
    @Min(value = 1, message = "Wymiar Y musi być większy od zera")
    private Integer dimY;

    @NotNull(message = "Podaj wymiar Z (cm)")
    @Min(value = 1, message = "Wymiar Z musi być większy od zera")
    private Integer dimZ;

    public BaggageCheckRequest() {
    }

    public String getReservationNumber() {
        return reservationNumber;
    }

    public void setReservationNumber(String reservationNumber) {
        this.reservationNumber = reservationNumber;
    }

    public BigDecimal getWeightKg() {
        return weightKg;
    }

    public void setWeightKg(BigDecimal weightKg) {
        this.weightKg = weightKg;
    }

    public Integer getDimX() {
        return dimX;
    }

    public void setDimX(Integer dimX) {
        this.dimX = dimX;
    }

    public Integer getDimY() {
        return dimY;
    }

    public void setDimY(Integer dimY) {
        this.dimY = dimY;
    }

    public Integer getDimZ() {
        return dimZ;
    }

    public void setDimZ(Integer dimZ) {
        this.dimZ = dimZ;
    }
}

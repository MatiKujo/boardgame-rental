package pl.edu.utp.po.baggage.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.math.BigDecimal;

/**
 * Encja "Lot" z treści zadania: trasa + limit bazowy (czyli ile kilogramów bagażu
 * można zabrać bez dopłaty).
 *
 * Celowo trzymamy tylko te dwa pola (dokładnie tak jak w treści zadania) -
 * limit objętości bagażu podręcznego jest za to STAŁY dla wszystkich lotów
 * (standardowy rozmiar kabinowy), więc nie musimy go trzymać osobno dla
 * każdego lotu w bazie - patrz stała CARRY_ON_MAX_VOLUME_CM3 w BaggageCalculatorService.
 */
@Entity
@Table(name = "flights")
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Trasa lotu, np. "Warszawa - Londyn".
    @Column(nullable = false)
    private String route;

    // Limit bazowy wagi bagażu (w kg) - do tej wagi klient NIE płaci nic dodatkowego.
    @Column(name = "base_weight_limit_kg", nullable = false)
    private BigDecimal baseWeightLimitKg;

    // Pusty konstruktor WYMAGANY przez JPA/Hibernate - nie usuwaj.
    public Flight() {
    }

    public Flight(String route, BigDecimal baseWeightLimitKg) {
        this.route = route;
        this.baseWeightLimitKg = baseWeightLimitKg;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public BigDecimal getBaseWeightLimitKg() {
        return baseWeightLimitKg;
    }

    public void setBaseWeightLimitKg(BigDecimal baseWeightLimitKg) {
        this.baseWeightLimitKg = baseWeightLimitKg;
    }
}

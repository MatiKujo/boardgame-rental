package pl.edu.utp.po.baggage.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import pl.edu.utp.po.baggage.dto.BaggageCheckRequest;
import pl.edu.utp.po.baggage.dto.BaggageCheckResponse;
import pl.edu.utp.po.baggage.service.BaggageService;

/**
 * Kontroler REST realizujący GŁÓWNY endpoint wymagany w treści zadania:
 * "Endpoint POST walidujący wprowadzony bagaż i zwracający sumę do dopłaty".
 *
 * Endpoint jest publiczny (permitAll w SecurityConfig) - "zamkiem" jest tutaj
 * numer rezerwacji: jeśli się nie zgadza, BaggageService rzuci wyjątek,
 * który RestExceptionHandler zamieni na odpowiedź 404 Not Found.
 */
@RestController
@Tag(name = "Baggage", description = "Odprawa online - walidacja bagażu i dopłata za nadbagaż")
public class BaggageRestController {

    private final BaggageService baggageService;

    public BaggageRestController(BaggageService baggageService) {
        this.baggageService = baggageService;
    }

    @Operation(summary = "Zwaliduj bagaż (waga + wymiary) i policz sumę do dopłaty za nadbagaż")
    @PostMapping("/api/baggage/check")
    public ResponseEntity<BaggageCheckResponse> checkBaggage(@Valid @RequestBody BaggageCheckRequest request) {
        return ResponseEntity.ok(baggageService.checkInBaggage(request));
    }
}

package pl.edu.utp.po.baggage.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.edu.utp.po.baggage.domain.Baggage;

import java.util.List;
import java.util.Optional;

public interface BaggageRepository extends JpaRepository<Baggage, Long> {

    // To jest zapytanie, które w praktyce "loguje" klienta - szukamy bagażu
    // (czyli rezerwacji) po numerze rezerwacji podanym przez klienta.
    Optional<Baggage> findByReservationNumber(String reservationNumber);

    // Wszystkie rezerwacje (bagaże) przypisane do danego lotu - widok pracownika.
    List<Baggage> findByFlightId(Long flightId);
}

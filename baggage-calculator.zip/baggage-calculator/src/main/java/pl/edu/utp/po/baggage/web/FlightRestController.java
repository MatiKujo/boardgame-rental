package pl.edu.utp.po.baggage.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import pl.edu.utp.po.baggage.dto.BaggageDto;
import pl.edu.utp.po.baggage.service.BaggageService;

import java.util.List;

/**
 * Kontroler REST dla pracownika lotniska - realizuje wymaganie z treści zadania:
 * "Pracownik lotniska widzi wszystkie bagaże danego lotu".
 *
 * Dostęp TYLKO dla zalogowanego pracownika (rola EMPLOYEE) - wymuszone w SecurityConfig.
 */
@RestController
@Tag(name = "Employee", description = "Podgląd bagaży danego lotu przez pracownika lotniska")
public class FlightRestController {

    private final BaggageService baggageService;

    public FlightRestController(BaggageService baggageService) {
        this.baggageService = baggageService;
    }

    @Operation(summary = "Pobierz listę wszystkich bagaży (rezerwacji) przypisanych do danego lotu (tylko EMPLOYEE)")
    @GetMapping("/api/flights/{id}/baggage")
    public ResponseEntity<List<BaggageDto>> getBaggageForFlight(@PathVariable("id") Long flightId) {
        return ResponseEntity.ok(baggageService.getBaggageForFlight(flightId));
    }
}

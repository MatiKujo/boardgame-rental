package pl.edu.utp.po.baggage.dto;

import java.math.BigDecimal;

/**
 * DTO zwracane klientowi po odprawie online - GŁÓWNA odpowiedź wymagana
 * w treści zadania: "Endpoint POST walidujący wprowadzony bagaż i zwracający
 * sumę do dopłaty".
 */
public class BaggageCheckResponse {

    private String reservationNumber;
    private String route;
    private BigDecimal weightKg;
    private BigDecimal baseWeightLimitKg;
    private BigDecimal overweightKg;
    private boolean volumeValid;
    private BigDecimal surchargeAmount;
    private String message;

    public BaggageCheckResponse() {
    }

    public BaggageCheckResponse(String reservationNumber, String route, BigDecimal weightKg,
                                 BigDecimal baseWeightLimitKg, BigDecimal overweightKg,
                                 boolean volumeValid, BigDecimal surchargeAmount, String message) {
        this.reservationNumber = reservationNumber;
        this.route = route;
        this.weightKg = weightKg;
        this.baseWeightLimitKg = baseWeightLimitKg;
        this.overweightKg = overweightKg;
        this.volumeValid = volumeValid;
        this.surchargeAmount = surchargeAmount;
        this.message = message;
    }

    public String getReservationNumber() {
        return reservationNumber;
    }

    public String getRoute() {
        return route;
    }

    public BigDecimal getWeightKg() {
        return weightKg;
    }

    public BigDecimal getBaseWeightLimitKg() {
        return baseWeightLimitKg;
    }

    public BigDecimal getOverweightKg() {
        return overweightKg;
    }

    public boolean isVolumeValid() {
        return volumeValid;
    }

    public BigDecimal getSurchargeAmount() {
        return surchargeAmount;
    }

    public String getMessage() {
        return message;
    }
}

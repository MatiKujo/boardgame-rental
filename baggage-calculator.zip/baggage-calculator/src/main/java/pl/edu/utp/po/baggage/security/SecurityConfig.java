package pl.edu.utp.po.baggage.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Konfiguracja bezpieczeństwa - CELOWO UPROSZCZONA względem "pełnego" systemu
 * logowania z tabelą użytkowników w bazie danych. Zgodnie z treścią zadania:
 *
 *   "Klient uwierzytelniony po numerze rezerwacji/ID" -> klient NIE loguje się
 *   przez Spring Security (nie ma hasła!). Jego "uwierzytelnienie" odbywa się
 *   wewnątrz BaggageService.checkInBaggage - musi znać poprawny numer rezerwacji,
 *   inaczej dostanie błąd. Dlatego strony/endpointy klienta (/checkin, /api/baggage/check)
 *   są w Spring Security oznaczone jako "permitAll" - każdy może je otworzyć,
 *   ale bez znajomości numeru rezerwacji nic nie zdziała.
 *
 *   "Pracownik lotniska widzi wszystkie bagaże danego lotu" -> TO już wymaga
 *   prawdziwego logowania z rolą, więc pracownik ma jedno konto zdefiniowane
 *   PROGRAMOWO poniżej (InMemoryUserDetailsManager) - bez osobnej tabeli w bazie,
 *   żeby nie rozbudowywać niepotrzebnie schematu bazy danych (miały być tylko
 *   2 tabele: Lot i Bagaż).
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * JEDNO konto pracownika lotniska, trzymane "w pamięci" (nie w bazie danych).
     * Login: pracownik, hasło: pracownik123.
     */
    @Bean
    public InMemoryUserDetailsManager userDetailsManager(PasswordEncoder passwordEncoder) {
        UserDetails employee = User.builder()
                .username("pracownik")
                .password(passwordEncoder.encode("pracownik123"))
                .roles("EMPLOYEE")
                .build();

        return new InMemoryUserDetailsManager(employee);
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/css/**", "/js/**", "/webjars/**").permitAll()
                        .requestMatchers("/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**").permitAll()
                        .requestMatchers("/h2-console/**").permitAll() // tylko do nauki/developmentu
                        .requestMatchers("/login").permitAll()

                        // Odprawa online (formularz + REST) - dostępna dla wszystkich w sensie
                        // Spring Security; prawdziwym "zamkiem" jest tu numer rezerwacji
                        // sprawdzany w BaggageService (patrz komentarz nad klasą).
                        .requestMatchers("/", "/checkin", "/checkin/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/baggage/check").permitAll()

                        // Panel pracownika (WWW + REST) - TYLKO zalogowany pracownik.
                        .requestMatchers("/employee/**").hasRole("EMPLOYEE")
                        .requestMatchers("/api/flights/**").hasRole("EMPLOYEE")

                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .defaultSuccessUrl("/employee/flights", true)
                        .permitAll()
                )
                // HTTP Basic - wygodne do testowania REST API z poziomu Swagger UI.
                .httpBasic(Customizer.withDefaults())
                .csrf(csrf -> csrf.ignoringRequestMatchers("/api/**", "/h2-console/**"))
                .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()))
                .logout(logout -> logout
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

        return http.build();
    }
}

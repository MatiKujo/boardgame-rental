package pl.edu.utp.po.baggage.dto;

import pl.edu.utp.po.baggage.domain.Baggage;

import java.math.BigDecimal;

/**
 * DTO zwracane pracownikowi lotniska - lista wszystkich bagaży (rezerwacji)
 * przypisanych do danego lotu. Nie zwracamy encji Baggage bezpośrednio,
 * żeby nie wystawiać na zewnątrz całej relacji do encji Flight.
 */
public class BaggageDto {

    private Long id;
    private String reservationNumber;
    private boolean checkedIn;
    private BigDecimal weightKg;
    private Integer dimX;
    private Integer dimY;
    private Integer dimZ;
    private Boolean volumeValid;
    private BigDecimal overweightFee;

    public BaggageDto() {
    }

    /** Zamienia encję Baggage na DTO gotowe do wysłania pracownikowi. */
    public static BaggageDto fromEntity(Baggage baggage) {
        BaggageDto dto = new BaggageDto();
        dto.id = baggage.getId();
        dto.reservationNumber = baggage.getReservationNumber();
        dto.checkedIn = baggage.isCheckedIn();
        dto.weightKg = baggage.getWeightKg();
        dto.dimX = baggage.getDimX();
        dto.dimY = baggage.getDimY();
        dto.dimZ = baggage.getDimZ();
        dto.volumeValid = baggage.getVolumeValid();
        dto.overweightFee = baggage.getOverweightFee();
        return dto;
    }

    public Long getId() {
        return id;
    }

    public String getReservationNumber() {
        return reservationNumber;
    }

    public boolean isCheckedIn() {
        return checkedIn;
    }

    public BigDecimal getWeightKg() {
        return weightKg;
    }

    public Integer getDimX() {
        return dimX;
    }

    public Integer getDimY() {
        return dimY;
    }

    public Integer getDimZ() {
        return dimZ;
    }

    public Boolean getVolumeValid() {
        return volumeValid;
    }

    public BigDecimal getOverweightFee() {
        return overweightFee;
    }
}

package pl.edu.utp.po.baggage.service;

import org.springframework.stereotype.Service;
import pl.edu.utp.po.baggage.domain.Baggage;
import pl.edu.utp.po.baggage.domain.Flight;
import pl.edu.utp.po.baggage.dto.BaggageCheckRequest;
import pl.edu.utp.po.baggage.dto.BaggageCheckResponse;
import pl.edu.utp.po.baggage.dto.BaggageDto;
import pl.edu.utp.po.baggage.repository.BaggageRepository;
import pl.edu.utp.po.baggage.repository.FlightRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Serwis "spinający w całość" proces odprawy online: znalezienie rezerwacji
 * po numerze (to jest właśnie "uwierzytelnienie" klienta - patrz treść zadania),
 * zapisanie podanej wagi/wymiarów oraz wyliczenie wyniku przez BaggageCalculatorService.
 */
@Service
public class BaggageService {

    private final BaggageRepository baggageRepository;
    private final FlightRepository flightRepository;
    private final BaggageCalculatorService calculatorService;

    public BaggageService(BaggageRepository baggageRepository,
                           FlightRepository flightRepository,
                           BaggageCalculatorService calculatorService) {
        this.baggageRepository = baggageRepository;
        this.flightRepository = flightRepository;
        this.calculatorService = calculatorService;
    }

    /**
     * GŁÓWNA metoda: wykonuje odprawę online dla klienta.
     *
     * "Uwierzytelnienie" klienta polega na tym, że numer rezerwacji MUSI pasować
     * do istniejącego w bazie bagażu/rezerwacji - jeśli nie pasuje, rzucamy wyjątek
     * (dokładnie tak, jak przy błędnym loginie). Klient nie podaje żadnego hasła -
     * zgodnie z treścią zadania: "Klient uwierzytelniony po numerze rezerwacji/ID".
     */
    public BaggageCheckResponse checkInBaggage(BaggageCheckRequest request) {

        Baggage baggage = baggageRepository.findByReservationNumber(request.getReservationNumber())
                .orElseThrow(() -> new NoSuchElementException(
                        "Nieprawidłowy numer rezerwacji: " + request.getReservationNumber()));

        Flight flight = baggage.getFlight();

        // Zapisujemy wagę i wymiary podane przez klienta w formularzu odprawy.
        baggage.setWeightKg(request.getWeightKg());
        baggage.setDimX(request.getDimX());
        baggage.setDimY(request.getDimY());
        baggage.setDimZ(request.getDimZ());

        // Uruchamiamy algorytm: walidacja gabarytów + wyliczenie dopłaty za nadbagaż.
        boolean volumeValid = calculatorService.isVolumeValid(request.getDimX(), request.getDimY(), request.getDimZ());
        BigDecimal overweightKg = calculatorService.calculateOverweightKg(request.getWeightKg(), flight.getBaseWeightLimitKg());
        BigDecimal surcharge = calculatorService.calculateSurcharge(request.getWeightKg(), flight.getBaseWeightLimitKg());

        baggage.setVolumeValid(volumeValid);
        baggage.setOverweightFee(surcharge);
        baggageRepository.save(baggage);

        String message = buildMessage(volumeValid, surcharge);

        return new BaggageCheckResponse(
                baggage.getReservationNumber(),
                flight.getRoute(),
                request.getWeightKg(),
                flight.getBaseWeightLimitKg(),
                overweightKg,
                volumeValid,
                surcharge,
                message
        );
    }

    /** Zwraca listę wszystkich bagaży (rezerwacji) przypisanych do danego lotu - widok pracownika. */
    public List<BaggageDto> getBaggageForFlight(Long flightId) {
        return baggageRepository.findByFlightId(flightId)
                .stream()
                .map(BaggageDto::fromEntity)
                .toList();
    }

    public List<Flight> getAllFlights() {
        return flightRepository.findAll();
    }

    public Flight getFlightOrThrow(Long flightId) {
        return flightRepository.findById(flightId)
                .orElseThrow(() -> new NoSuchElementException("Nie znaleziono lotu o id " + flightId));
    }

    /** Buduje czytelny komunikat podsumowujący wynik odprawy - pokazywany klientowi w UI. */
    private String buildMessage(boolean volumeValid, BigDecimal surcharge) {
        StringBuilder message = new StringBuilder();

        message.append(volumeValid
                ? "Bagaż podręczny mieści się w dopuszczalnej objętości. "
                : "UWAGA: bagaż podręczny PRZEKRACZA dopuszczalną objętość kabinową! ");

        message.append(surcharge.compareTo(BigDecimal.ZERO) > 0
                ? "Naliczono dopłatę za nadbagaż w wysokości " + surcharge + " zł."
                : "Waga bagażu mieści się w limicie - brak dopłaty.");

        return message.toString();
    }
}

package pl.edu.utp.po.baggage.service;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * BaggageCalculatorService = serce projektu: czysty algorytm (bez bazy danych,
 * bez Springa poza samą adnotacją @Service), który:
 *   1) sprawdza, czy bagaż podręczny mieści się w dopuszczalnej OBJĘTOŚCI,
 *   2) liczy dopłatę za NADBAGAŻ (za każdy kilogram powyżej limitu wagowego danego lotu).
 *
 * Rozdzielenie tej logiki od reszty aplikacji (BaggageService, kontrolery) sprawia,
 * że bardzo łatwo się ją testuje jednostkowo - patrz BaggageCalculatorServiceTest.
 */
@Service
public class BaggageCalculatorService {

    /**
     * Standardowy maksymalny wymiar bagażu podręcznego to 55 x 40 x 20 cm
     * (typowy limit kabinowy stosowany przez większość linii lotniczych).
     * Stąd maksymalna dopuszczalna OBJĘTOŚĆ = 55 * 40 * 20 = 44 000 cm³.
     *
     * Ten limit jest STAŁY dla wszystkich lotów - dlatego nie trzymamy go
     * w bazie danych osobno dla każdego lotu (zgodnie z założeniem uproszczonej
     * bazy danych - patrz komentarz w encji Flight).
     */
    public static final int CARRY_ON_MAX_VOLUME_CM3 = 55 * 40 * 20;

    /** Stawka dopłaty za KAŻDY (zaokrąglony w górę) kilogram bagażu powyżej limitu wagowego lotu. */
    public static final BigDecimal FEE_PER_KG_OVER = new BigDecimal("50.00");

    /**
     * Sprawdza, czy bagaż o podanych wymiarach (w centymetrach) mieści się
     * w dopuszczalnym limicie objętości bagażu podręcznego.
     *
     * @return true, jeśli objętość (dimX * dimY * dimZ) NIE przekracza limitu
     */
    public boolean isVolumeValid(int dimX, int dimY, int dimZ) {
        if (dimX <= 0 || dimY <= 0 || dimZ <= 0) {
            throw new IllegalArgumentException("Wymiary bagażu muszą być większe od zera");
        }

        long volume = (long) dimX * dimY * dimZ;
        return volume <= CARRY_ON_MAX_VOLUME_CM3;
    }

    /**
     * Liczy, o ile kilogramów bagaż przekracza limit wagowy danego lotu.
     * Wynik jest ZAOKRĄGLONY W GÓRĘ do pełnego kilograma (tak jak w prawdziwych
     * liniach lotniczych - nawet 0,1 kg nadwyżki liczy się jako cały kilogram).
     * Jeśli bagaż mieści się w limicie (albo jest dokładnie na limicie), zwraca 0.
     */
    public BigDecimal calculateOverweightKg(BigDecimal weightKg, BigDecimal baseWeightLimitKg) {
        validateWeights(weightKg, baseWeightLimitKg);

        BigDecimal difference = weightKg.subtract(baseWeightLimitKg);

        if (difference.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }

        // Zaokrąglenie w górę do pełnego kilograma (scale = 0, RoundingMode.CEILING).
        return difference.setScale(0, RoundingMode.CEILING);
    }

    /**
     * Główna metoda algorytmu - liczy CAŁKOWITĄ kwotę dopłaty za nadbagaż:
     * (liczba kilogramów nadwyżki, zaokrąglona w górę) * (stawka za kilogram).
     * Zwraca 0,00 zł, jeśli bagaż mieści się w limicie wagowym.
     */
    public BigDecimal calculateSurcharge(BigDecimal weightKg, BigDecimal baseWeightLimitKg) {
        BigDecimal overweightKg = calculateOverweightKg(weightKg, baseWeightLimitKg);

        return overweightKg.multiply(FEE_PER_KG_OVER).setScale(2, RoundingMode.HALF_UP);
    }

    private void validateWeights(BigDecimal weightKg, BigDecimal baseWeightLimitKg) {
        if (weightKg == null || weightKg.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Waga bagażu musi być większa od zera");
        }
        if (baseWeightLimitKg == null || baseWeightLimitKg.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Limit bazowy lotu musi być większy od zera");
        }
    }
}

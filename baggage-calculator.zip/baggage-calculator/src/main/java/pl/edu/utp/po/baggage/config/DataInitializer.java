package pl.edu.utp.po.baggage.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import pl.edu.utp.po.baggage.domain.Baggage;
import pl.edu.utp.po.baggage.domain.Flight;
import pl.edu.utp.po.baggage.repository.BaggageRepository;
import pl.edu.utp.po.baggage.repository.FlightRepository;

import java.math.BigDecimal;
import java.util.List;

/**
 * Uruchamia się automatycznie zaraz po starcie aplikacji i zasila pustą (bo "w pamięci")
 * bazę H2 przykładowymi lotami i rezerwacjami (bagażami) - część z nich JUŻ ma podaną
 * wagę/wymiary (jakby ktoś zrobił odprawę wcześniej), a część czeka na odprawę online.
 *
 * Zgodnie z Twoją prośbą, do przejścia po listach używamy METODY forEach (z wyrażeniem
 * lambda), a NIE klasycznej pętli "for (Typ x : lista) { ... }".
 */
@Component
public class DataInitializer implements ApplicationRunner {

    private final FlightRepository flightRepository;
    private final BaggageRepository baggageRepository;

    public DataInitializer(FlightRepository flightRepository, BaggageRepository baggageRepository) {
        this.flightRepository = flightRepository;
        this.baggageRepository = baggageRepository;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (flightRepository.count() > 0) {
            return; // dane już istnieją (np. po restarcie) - nie dodawaj drugi raz
        }

        // Przygotowujemy listę lotów do zapisania i zapisujemy je JEDNĄ linijką
        // przez forEach (zamiast pętli for) - Spring Data JPA sam nada im ID.
        List<Flight> flightsToSeed = List.of(
                new Flight("Warszawa - Londyn", new BigDecimal("20")),
                new Flight("Warszawa - Nowy Jork", new BigDecimal("23")),
                new Flight("Warszawa - Barcelona", new BigDecimal("20"))
        );
        flightsToSeed.forEach(flightRepository::save);

        Flight londyn = flightsToSeed.get(0);
        Flight nowyJork = flightsToSeed.get(1);
        Flight barcelona = flightsToSeed.get(2);

        // Kilka przykładowych rezerwacji (bagaży) - część JUŻ odprawiona (ma wagę/wymiary),
        // część czeka na odprawę online przez klienta.
        Baggage rez1 = new Baggage(londyn, "RES-1001"); // czeka na odprawę
        Baggage rez2 = new Baggage(nowyJork, "RES-1002"); // czeka na odprawę
        Baggage rez3 = new Baggage(barcelona, "RES-1003"); // czeka na odprawę

        // Ta rezerwacja jest już odprawiona - świetny przykład nadbagażu do pokazania
        // na egzaminie (limit 20 kg, waga 27,5 kg -> nadwyżka 8 kg po zaokrągleniu w górę * 50 zł = 400 zł).
        Baggage rez4 = new Baggage(londyn, "RES-1004");
        rez4.setWeightKg(new BigDecimal("27.5"));
        rez4.setDimX(60);
        rez4.setDimY(45);
        rez4.setDimZ(25);
        rez4.setVolumeValid(false); // 60*45*25 = 67500 cm³ > 44000 cm³ limitu kabinowego
        rez4.setOverweightFee(new BigDecimal("400.00"));

        List.of(rez1, rez2, rez3, rez4).forEach(baggageRepository::save);
    }
}

package pl.edu.utp.po.baggage.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Testy jednostkowe dla BaggageCalculatorService - wymaganie z treści zadania:
 * "Testy logiki sprawdzania limitów objętości i wagi".
 *
 * Uruchomienie: `mvn test` albo prawy klik na klasę w IDE -> Run.
 */
class BaggageCalculatorServiceTest {

    private final BaggageCalculatorService calculator = new BaggageCalculatorService();

    @Test
    @DisplayName("Standardowe wymiary kabinowe (55x40x20) -> gabaryty OK (dokładnie na granicy limitu)")
    void standardCarryOnSize_isValid() {
        boolean valid = calculator.isVolumeValid(55, 40, 20);

        assertThat(valid).isTrue();
    }

    @Test
    @DisplayName("Bagaż większy niż limit objętości -> gabaryty NIEPRAWIDŁOWE")
    void oversizedBaggage_isInvalid() {
        boolean valid = calculator.isVolumeValid(60, 45, 25); // 67 500 cm³ > 44 000 cm³

        assertThat(valid).isFalse();
    }

    @Test
    @DisplayName("Mały bagaż -> gabaryty OK")
    void smallBaggage_isValid() {
        boolean valid = calculator.isVolumeValid(30, 20, 15);

        assertThat(valid).isTrue();
    }

    @Test
    @DisplayName("Waga w granicach limitu -> brak nadwyżki i brak dopłaty")
    void weightWithinLimit_noSurcharge() {
        BigDecimal overweight = calculator.calculateOverweightKg(new BigDecimal("18"), new BigDecimal("20"));
        BigDecimal surcharge = calculator.calculateSurcharge(new BigDecimal("18"), new BigDecimal("20"));

        assertThat(overweight).isEqualByComparingTo("0");
        assertThat(surcharge).isEqualByComparingTo("0.00");
    }

    @Test
    @DisplayName("Waga DOKŁADNIE na limicie -> brak dopłaty")
    void weightExactlyAtLimit_noSurcharge() {
        BigDecimal surcharge = calculator.calculateSurcharge(new BigDecimal("20"), new BigDecimal("20"));

        assertThat(surcharge).isEqualByComparingTo("0.00");
    }

    @Test
    @DisplayName("Nadwyżka wagi jest zaokrąglana W GÓRĘ do pełnego kilograma (np. 27,5 kg przy limicie 20 kg -> 8 kg)")
    void overweightIsRoundedUpToFullKg() {
        BigDecimal overweight = calculator.calculateOverweightKg(new BigDecimal("27.5"), new BigDecimal("20"));

        assertThat(overweight).isEqualByComparingTo("8"); // 7.5 kg zaokrąglone w górę -> 8 kg
    }

    @Test
    @DisplayName("Dopłata = zaokrąglona nadwyżka (kg) * 50 zł/kg")
    void surchargeEqualsOverweightTimesRate() {
        // limit 20 kg, waga 24 kg -> nadwyżka 4 kg -> 4 * 50 zł = 200,00 zł
        BigDecimal surcharge = calculator.calculateSurcharge(new BigDecimal("24"), new BigDecimal("20"));

        assertThat(surcharge).isEqualByComparingTo("200.00");
    }

    @Test
    @DisplayName("Wymiar równy zero lub ujemny -> wyjątek IllegalArgumentException")
    void invalidDimension_throwsException() {
        assertThatThrownBy(() -> calculator.isVolumeValid(0, 40, 20))
                .isInstanceOf(IllegalArgumentException.class);

        assertThatThrownBy(() -> calculator.isVolumeValid(55, -5, 20))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("Waga równa zero lub ujemna -> wyjątek IllegalArgumentException")
    void invalidWeight_throwsException() {
        assertThatThrownBy(() -> calculator.calculateSurcharge(BigDecimal.ZERO, new BigDecimal("20")))
                .isInstanceOf(IllegalArgumentException.class);

        assertThatThrownBy(() -> calculator.calculateSurcharge(new BigDecimal("-3"), new BigDecimal("20")))
                .isInstanceOf(IllegalArgumentException.class);
    }
}

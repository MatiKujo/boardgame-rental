# Kalkulator bagażu lotniczego - Dopłaty za nadbagaż

Projekt zaliczeniowy: Spring Boot (Java) + Thymeleaf (UI) + REST API + Swagger +
Spring Security + testy jednostkowe (JUnit 5).

## WAŻNA UWAGA - ten projekt jest CELOWO prostszy

Zgodnie z Twoją prośbą (punktacja ~10-11/20, a nie maksymalna), ten projekt jest
świadomie mniej rozbudowany niż "pełny" system z pięcioma rolami i dziesiątkami
endpointów. Konkretnie:

- **Baza danych ma TYLKO 2 tabele** - dokładnie `Flight` (Lot) i `Baggage` (Bagaż),
  zgodnie z treścią zadania. Limit objętości bagażu podręcznego (55x40x20 cm) jest
  stałą w kodzie (`BaggageCalculatorService.CARRY_ON_MAX_VOLUME_CM3`), a nie osobną
  kolumną w bazie dla każdego lotu - bo w treści zadania limit objętości nie jest
  wymieniony jako pole encji `Lot`.
- **Pracownik ma JEDNO konto "na sztywno"** w konfiguracji (`SecurityConfig`,
  `InMemoryUserDetailsManager`) zamiast osobnej tabeli użytkowników w bazie.
- **Klient NIE loguje się przez Spring Security** - zgodnie z treścią zadania
  ("Klient uwierzytelniony po numerze rezerwacji/ID") jego "hasłem" jest po prostu
  numer rezerwacji, sprawdzany wewnątrz `BaggageService.checkInBaggage(...)`.

Mimo uproszczeń, **wszystko działa end-to-end** i realizuje każdy punkt z treści zadania.

## Co jest w środku

- **Baza danych**: `Flight` (Lot: trasa, limit bazowy), `Baggage` (Bagaż: waga,
  wymiary X/Y/Z, numer rezerwacji) - zasilane danymi startowymi automatycznie
  (`DataInitializer`, korzysta z `forEach` zamiast pętli `for`, zgodnie z prośbą).
- **Webowe UI (Thymeleaf)**: `/checkin` - GŁÓWNY widok odprawy online (wpisujesz
  numer rezerwacji + wagę + wymiary, dostajesz wynik: gabaryty OK/NIE + kwota dopłaty).
  `/employee/flights` i `/employee/flights/{id}/baggage` - panel pracownika.
- **Algorytm**: `BaggageCalculatorService` - `isVolumeValid(...)` sprawdza objętość
  bagażu podręcznego (limit 55x40x20 cm = 44 000 cm³), `calculateSurcharge(...)`
  liczy dopłatę za nadbagaż (50 zł za każdy - zaokrąglony w górę - kilogram nadwyżki).
- **REST + Swagger**: `POST /api/baggage/check` - GŁÓWNY endpoint: waliduje bagaż
  i zwraca sumę do dopłaty. Dokumentacja pod `/swagger-ui.html`.
- **Security**: klient "loguje się" numerem rezerwacji (bez hasła), pracownik loguje
  się normalnie (Spring Security, jedno konto) i widzi wszystkie bagaże danego lotu.
- **Testy**: `BaggageCalculatorServiceTest` - testy logiki sprawdzania limitów
  objętości i wagi (dokładnie to, czego wymaga treść zadania).

## Wymagania do uruchomienia

- **Java 17** lub nowsza
- **Maven** - lub po prostu zaimportuj folder jako projekt Maven w IntelliJ IDEA / Eclipse.

## Jak uruchomić

### Opcja A: z terminala (Maven)
```bash
mvn spring-boot:run
```

### Opcja B: z IDE
1. Otwórz folder `baggage-calculator` jako projekt Maven (File -> Open -> wskaż `pom.xml`).
2. Poczekaj, aż IDE pobierze zależności.
3. Kliknij prawym na `BaggageCalculatorApplication.java` -> **Run**.

### Opcja C: zbuduj gotowy .jar
```bash
mvn clean package
java -jar target/baggage-calculator.jar
```

Aplikacja wystartuje na porcie **8080**.

## Adresy po uruchomieniu

| Co | Adres |
|---|---|
| Odprawa online (widok klienta) | http://localhost:8080/checkin |
| Panel pracownika (wymaga logowania) | http://localhost:8080/employee/flights |
| Dokumentacja API (Swagger) | http://localhost:8080/swagger-ui.html |
| Konsola bazy danych H2 | http://localhost:8080/h2-console |

**Dane logowania do H2 console**: JDBC URL = `jdbc:h2:mem:baggagedb`, user = `sa`, hasło = puste.

## Dane testowe

### Numery rezerwacji do wypróbowania na `/checkin` (klient - bez hasła!)

| Numer rezerwacji | Lot | Limit bazowy |
|---|---|---|
| `RES-1001` | Warszawa - Londyn | 20 kg |
| `RES-1002` | Warszawa - Nowy Jork | 23 kg |
| `RES-1003` | Warszawa - Barcelona | 20 kg |
| `RES-1004` | Warszawa - Londyn | 20 kg (JUŻ odprawiony - 27,5 kg, nadbagaż 400 zł) |

Spróbuj np. numeru `RES-1001` z wagą `24` kg i wymiarami `50/40/20` - zobaczysz
dopłatę 200 zł (4 kg nadwyżki * 50 zł) i informację, że gabaryty są w porządku.

Spróbuj też numeru, którego nie ma w bazie (np. `RES-9999`) - dostaniesz komunikat
o nieprawidłowym numerze rezerwacji (to jest właśnie owo "uwierzytelnienie klienta").

### Konto pracownika lotniska

| Login | Hasło |
|---|---|
| `pracownik` | `pracownik123` |

## Główne endpointy REST

- `POST /api/baggage/check` - **GŁÓWNY endpoint**: waliduje bagaż i zwraca sumę do
  dopłaty. Przykładowe body:
  ```json
  { "reservationNumber": "RES-1001", "weightKg": 24, "dimX": 50, "dimY": 40, "dimZ": 20 }
  ```
- `GET /api/flights/{id}/baggage` - lista wszystkich bagaży (rezerwacji) danego lotu
  (**tylko zalogowany pracownik**)

Najwygodniej przetestować w Swagger UI (`/swagger-ui.html`) - dla endpointu pracownika
kliknij "Authorize" i podaj login/hasło z tabeli powyżej (Basic Auth). Endpoint
`/api/baggage/check` nie wymaga logowania w Swaggerze.

## Algorytm (BaggageCalculatorService)

1. **Walidacja gabarytów**: `objętość = dimX * dimY * dimZ` (w cm³). Jeśli objętość
   przekracza 44 000 cm³ (standardowy limit kabinowy 55x40x20 cm) -> gabaryty NIEPRAWIDŁOWE.
2. **Dopłata za nadbagaż**: `nadwyżka = waga - limit_bazowy_lotu`, zaokrąglona W GÓRĘ
   do pełnego kilograma (nawet 0,1 kg nadwyżki liczy się jako cały kilogram - tak jak
   w prawdziwych liniach lotniczych). Jeśli nadwyżka <= 0 -> dopłata 0 zł.
   W przeciwnym razie: `dopłata = nadwyżka(kg) * 50 zł`.

Pełny komplet testów: `src/test/java/pl/edu/utp/po/baggage/service/BaggageCalculatorServiceTest.java`

## Jak uruchomić testy

```bash
mvn test
```

## Struktura projektu

```
pl.edu.utp.po.baggage
├── domain          -> encje bazodanowe (Flight, Baggage) - TYLKO 2 tabele
├── repository       -> interfejsy Spring Data JPA
├── service          -> logika biznesowa (BaggageCalculatorService - algorytm!, BaggageService)
├── security         -> konfiguracja Spring Security (jedno konto pracownika "w pamięci")
├── web              -> kontrolery REST (@RestController) + obsługa błędów
├── controller       -> kontroler MVC (Thymeleaf, strony HTML)
├── dto              -> obiekty transferu danych (request/response)
└── config           -> DataInitializer (dane startowe, korzysta z forEach)
```

## Uwaga

Każdy plik `.java` jest obficie skomentowany po polsku - specjalnie po to, żeby dało
się z niego uczyć / bronić projektu na egzaminie bez wcześniejszej dobrej znajomości
Javy i Springa. Zacznij czytanie od `BaggageCalculatorService.java` (serce algorytmu)
i `SecurityConfig.java` (tam jest wyjaśnione, dlaczego bezpieczeństwo jest uproszczone).

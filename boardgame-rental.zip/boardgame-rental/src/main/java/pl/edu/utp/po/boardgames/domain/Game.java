package pl.edu.utp.po.boardgames.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Encja "Gra" z treści zadania: tytuł + kategoria rzadkości.
 * Każdy wiersz w tabeli "games" reprezentuje JEDEN fizyczny egzemplarz gry
 * w wypożyczalni (uproszczenie - w prawdziwym systemie mogłoby być więcej
 * egzemplarzy tego samego tytułu, tutaj dla prostoty: 1 wiersz = 1 sztuka).
 */
@Entity
@Table(name = "games")
public class Game {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    // @Enumerated(EnumType.STRING) -> w bazie danych kategoria zapisana jest jako
    // czytelny tekst ("COMMON", "RARE" itd.), a nie jako liczba porządkowa enuma.
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private GameCategory category;

    // Pusty konstruktor WYMAGANY przez JPA/Hibernate - nie usuwaj.
    public Game() {
    }

    public Game(String title, GameCategory category) {
        this.title = title;
        this.category = category;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public GameCategory getCategory() {
        return category;
    }

    public void setCategory(GameCategory category) {
        this.category = category;
    }
}

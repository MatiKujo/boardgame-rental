package pl.edu.utp.po.boardgames.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.edu.utp.po.boardgames.dto.DebtSummaryResponse;
import pl.edu.utp.po.boardgames.service.RentalService;

/**
 * Kontroler REST realizujący GŁÓWNY endpoint wymagany w treści zadania:
 * "Endpoint GET zwracający aktualne zadłużenie użytkownika".
 *
 * WAŻNE (bezpieczeństwo): login klienta, którego zadłużenie liczymy, ZAWSZE
 * bierzemy z obiektu Authentication (czyli z aktualnie zalogowanej sesji),
 * nigdy z parametru URL podanego przez klienta - dzięki temu klient fizycznie
 * nie może podejrzeć zadłużenia innej osoby ("Klient widzi swój panel zadłużenia").
 */
@RestController
@Tag(name = "Debts", description = "Aktualne zadłużenie klienta z tytułu kar za opóźnienia")
public class DebtRestController {

    private final RentalService rentalService;

    public DebtRestController(RentalService rentalService) {
        this.rentalService = rentalService;
    }

    @Operation(summary = "Pobierz aktualne zadłużenie zalogowanego klienta (suma kar + lista wypożyczeń)")
    @GetMapping("/api/debts/my")
    public ResponseEntity<DebtSummaryResponse> getMyDebt(Authentication authentication) {
        return ResponseEntity.ok(rentalService.getDebtSummary(authentication.getName()));
    }
}

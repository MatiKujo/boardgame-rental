package pl.edu.utp.po.boardgames.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Użytkownik aplikacji. Rola jest prostym Stringiem: "CUSTOMER" albo "EMPLOYEE".
 *   - CUSTOMER (klient) -> widzi TYLKO swój panel zadłużenia i swoje wypożyczenia,
 *   - EMPLOYEE (pracownik) -> może dodatkowo oznaczyć DOWOLNĄ grę jako zwróconą.
 *
 * Spring Security wymaga prefiksu "ROLE_" dla nazw uprawnień (np. "ROLE_EMPLOYEE") -
 * dbamy o to w CustomUserDetailsService.
 */
@Entity
@Table(name = "app_users")
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    // Hasło JEST zapisane w bazie już zahashowane (BCrypt) - nigdy jawnym tekstem!
    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String role; // "CUSTOMER" albo "EMPLOYEE"

    private String fullName;

    public AppUser() {
    }

    public AppUser(String username, String password, String role, String fullName) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.fullName = fullName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}

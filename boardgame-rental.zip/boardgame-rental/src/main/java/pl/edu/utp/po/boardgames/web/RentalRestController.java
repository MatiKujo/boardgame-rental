package pl.edu.utp.po.boardgames.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import pl.edu.utp.po.boardgames.domain.Game;
import pl.edu.utp.po.boardgames.dto.BorrowRequest;
import pl.edu.utp.po.boardgames.dto.RentalDto;
import pl.edu.utp.po.boardgames.service.RentalService;

import java.util.List;

/**
 * Kontroler REST dla wypożyczeń: lista dostępnych gier, wypożyczanie, podgląd
 * własnych/wszystkich aktywnych wypożyczeń oraz zwrot gry (tylko pracownik).
 */
@RestController
@Tag(name = "Rentals", description = "Wypożyczanie, przeglądanie i zwrot gier planszowych")
public class RentalRestController {

    private final RentalService rentalService;

    public RentalRestController(RentalService rentalService) {
        this.rentalService = rentalService;
    }

    @Operation(summary = "Pobierz listę gier dostępnych aktualnie do wypożyczenia")
    @GetMapping("/api/games/available")
    public ResponseEntity<List<Game>> getAvailableGames() {
        return ResponseEntity.ok(rentalService.getAvailableGames());
    }

    @Operation(summary = "Wypożycz grę (termin zwrotu ustalany automatycznie na 14 dni)")
    @PostMapping("/api/rentals")
    public ResponseEntity<RentalDto> borrowGame(@Valid @RequestBody BorrowRequest request,
                                                 Authentication authentication) {
        RentalDto dto = rentalService.borrowGame(authentication.getName(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    @Operation(summary = "Pobierz listę własnych aktualnie wypożyczonych gier (z naliczonymi karami)")
    @GetMapping("/api/rentals/my")
    public ResponseEntity<List<RentalDto>> getMyRentals(Authentication authentication) {
        return ResponseEntity.ok(rentalService.getActiveRentalsForUser(authentication.getName()));
    }

    @Operation(summary = "Pobierz listę WSZYSTKICH aktywnych wypożyczeń (tylko EMPLOYEE)")
    @GetMapping("/api/rentals/active")
    public ResponseEntity<List<RentalDto>> getAllActiveRentals() {
        return ResponseEntity.ok(rentalService.getAllActiveRentals());
    }

    @Operation(summary = "Oznacz grę jako zwróconą i zamroź ostateczną karę (tylko EMPLOYEE)")
    @PostMapping("/api/rentals/{id}/return")
    public ResponseEntity<RentalDto> returnGame(@PathVariable("id") Long rentalId) {
        return ResponseEntity.ok(rentalService.returnGame(rentalId));
    }
}

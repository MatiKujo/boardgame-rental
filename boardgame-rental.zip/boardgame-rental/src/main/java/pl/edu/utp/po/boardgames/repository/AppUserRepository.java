package pl.edu.utp.po.boardgames.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.edu.utp.po.boardgames.domain.AppUser;

import java.util.Optional;

public interface AppUserRepository extends JpaRepository<AppUser, Long> {

    Optional<AppUser> findByUsername(String username);
}

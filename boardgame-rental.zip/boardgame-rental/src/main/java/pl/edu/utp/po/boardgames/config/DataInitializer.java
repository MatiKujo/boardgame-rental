package pl.edu.utp.po.boardgames.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import pl.edu.utp.po.boardgames.domain.AppUser;
import pl.edu.utp.po.boardgames.domain.Game;
import pl.edu.utp.po.boardgames.domain.GameCategory;
import pl.edu.utp.po.boardgames.domain.Rental;
import pl.edu.utp.po.boardgames.repository.AppUserRepository;
import pl.edu.utp.po.boardgames.repository.GameRepository;
import pl.edu.utp.po.boardgames.repository.RentalRepository;

import java.time.LocalDate;

/**
 * Uruchamia się automatycznie zaraz po starcie aplikacji i zasila pustą (bo "w pamięci")
 * bazę H2 przykładowymi danymi: grami, użytkownikami oraz kilkoma wypożyczeniami -
 * W TYM CELOWO JEDNYM PRZETERMINOWANYM - żeby od razu, bez klikania, było widać
 * działającą karę w panelu klienta.
 *
 * Hasła są hashowane PROGRAMOWO przez PasswordEncoder - logowanie na pewno zadziała.
 */
@Component
public class DataInitializer implements ApplicationRunner {

    private final AppUserRepository appUserRepository;
    private final GameRepository gameRepository;
    private final RentalRepository rentalRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(AppUserRepository appUserRepository,
                            GameRepository gameRepository,
                            RentalRepository rentalRepository,
                            PasswordEncoder passwordEncoder) {
        this.appUserRepository = appUserRepository;
        this.gameRepository = gameRepository;
        this.rentalRepository = rentalRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(ApplicationArguments args) {
        seedUsers();
        seedGamesAndRentals();
    }

    private void seedUsers() {
        if (appUserRepository.count() > 0) {
            return;
        }

        // KLIENT: login "user", hasło "user123"
        appUserRepository.save(new AppUser(
                "user", passwordEncoder.encode("user123"), "CUSTOMER", "Jan Kowalski"));

        // Drugi klient - przydatny, żeby pokazać, że klient A nie widzi zadłużenia klienta B.
        appUserRepository.save(new AppUser(
                "ewa", passwordEncoder.encode("ewa12345"), "CUSTOMER", "Ewa Nowak"));

        // PRACOWNIK wypożyczalni: login "pracownik", hasło "pracownik123" -
        // jedyna rola mogąca oznaczyć grę jako zwróconą.
        appUserRepository.save(new AppUser(
                "pracownik", passwordEncoder.encode("pracownik123"), "EMPLOYEE", "Pracownik Wypożyczalni"));
    }

    private void seedGamesAndRentals() {
        if (gameRepository.count() > 0) {
            return;
        }

        Game catan = gameRepository.save(new Game("Catan", GameCategory.COMMON));
        Game monopoly = gameRepository.save(new Game("Monopoly", GameCategory.COMMON));
        Game scrabble = gameRepository.save(new Game("Scrabble", GameCategory.COMMON));
        Game terraformingMars = gameRepository.save(new Game("Terraforming Mars", GameCategory.UNCOMMON));
        Game pandemicLegacy = gameRepository.save(new Game("Pandemic Legacy", GameCategory.UNCOMMON));
        Game gloomhaven = gameRepository.save(new Game("Gloomhaven", GameCategory.RARE));

        LocalDate today = LocalDate.now();

        // Wypożyczenie NR 1: PRZETERMINOWANE o 6 dni, kategoria RARE (10 zł/dzień)
        // -> kara = 6 * 10 = 60,00 zł. Świetny przykład do pokazania na egzaminie.
        AppUser user = appUserRepository.findByUsername("user").orElseThrow();
        rentalRepository.save(new Rental(gloomhaven, user, today.minusDays(20), today.minusDays(6)));

        // Wypożyczenie NR 2: WCIĄŻ W TERMINIE (termin za 11 dni) -> kara = 0,00 zł.
        rentalRepository.save(new Rental(catan, user, today.minusDays(3), today.plusDays(11)));

        // Wypożyczenie NR 3: drugi klient, przeterminowane o 2 dni, kategoria UNCOMMON (5 zł/dzień)
        // -> kara = 2 * 5 = 10,00 zł.
        AppUser ewa = appUserRepository.findByUsername("ewa").orElseThrow();
        rentalRepository.save(new Rental(terraformingMars, ewa, today.minusDays(10), today.minusDays(2)));

        // Pozostałe gry (monopoly, scrabble, pandemicLegacy) NIE są nikomu wypożyczone -
        // widać je od razu na liście "Dostępne gry" do wypożyczenia.
    }
}

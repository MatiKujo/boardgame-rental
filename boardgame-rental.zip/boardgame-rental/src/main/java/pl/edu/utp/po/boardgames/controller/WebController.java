package pl.edu.utp.po.boardgames.controller;

import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import pl.edu.utp.po.boardgames.dto.BorrowRequest;
import pl.edu.utp.po.boardgames.service.RentalService;

/**
 * Kontroler MVC (widoki HTML renderowane przez Thymeleaf).
 */
@Controller
public class WebController {

    private final RentalService rentalService;

    public WebController(RentalService rentalService) {
        this.rentalService = rentalService;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/my-rentals";
    }

    /**
     * GET /my-rentals
     * GŁÓWNY widok wymagany w treści zadania: "Widok wypożyczonych aktualnie gier
     * przez użytkownika z informacją o ewentualnych karach".
     */
    @GetMapping("/my-rentals")
    public String myRentals(Authentication authentication, Model model) {
        var activeRentals = rentalService.getActiveRentalsForUser(authentication.getName());
        model.addAttribute("rentals", activeRentals);

        // Suma wszystkich aktualnych kar - wyświetlana na górze strony jako "Twoje zadłużenie".
        var totalDebt = activeRentals.stream()
                .map(r -> r.getCurrentFee())
                .reduce(java.math.BigDecimal.ZERO, java.math.BigDecimal::add);
        model.addAttribute("totalDebt", totalDebt);

        return "my-rentals"; // -> templates/my-rentals.html
    }

    /** GET /games -> lista dostępnych gier + formularz wypożyczenia. */
    @GetMapping("/games")
    public String showAvailableGames(Model model) {
        model.addAttribute("games", rentalService.getAvailableGames());

        if (!model.containsAttribute("borrowRequest")) {
            model.addAttribute("borrowRequest", new BorrowRequest());
        }

        return "games"; // -> templates/games.html
    }

    /** POST /borrow -> wypożyczenie wybranej gry przez zalogowanego klienta. */
    @PostMapping("/borrow")
    public String borrowGame(@Valid @ModelAttribute("borrowRequest") BorrowRequest request,
                              BindingResult bindingResult,
                              Authentication authentication,
                              Model model,
                              RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("games", rentalService.getAvailableGames());
            return "games";
        }

        try {
            rentalService.borrowGame(authentication.getName(), request);
            redirectAttributes.addFlashAttribute("successMessage", "Gra została wypożyczona na 14 dni.");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", "Błąd: " + ex.getMessage());
        }

        return "redirect:/games";
    }

    /**
     * GET /employee/rentals
     * Panel pracownika - lista WSZYSTKICH aktywnych wypożyczeń z przyciskiem "Zwróć".
     * Dostęp wymuszony w SecurityConfig ("/employee/**" -> hasRole("EMPLOYEE")).
     */
    @GetMapping("/employee/rentals")
    public String employeeRentals(Model model) {
        model.addAttribute("rentals", rentalService.getAllActiveRentals());
        return "employee-rentals"; // -> templates/employee-rentals.html
    }

    /** POST /employee/rentals/{id}/return -> pracownik oznacza grę jako zwróconą. */
    @PostMapping("/employee/rentals/{id}/return")
    public String returnGame(@PathVariable("id") Long rentalId, RedirectAttributes redirectAttributes) {
        try {
            var dto = rentalService.returnGame(rentalId);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Gra \"" + dto.getGameTitle() + "\" została zwrócona. Naliczona kara: " + dto.getCurrentFee() + " zł");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", "Błąd: " + ex.getMessage());
        }
        return "redirect:/employee/rentals";
    }
}

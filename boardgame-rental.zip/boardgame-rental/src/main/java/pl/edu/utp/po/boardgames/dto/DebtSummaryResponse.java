package pl.edu.utp.po.boardgames.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * DTO zwracane przez GŁÓWNY endpoint wymagany w treści zadania:
 * "Endpoint GET zwracający aktualne zadłużenie użytkownika".
 *
 * Zawiera sumę wszystkich kar (totalDebt) oraz listę wypożyczeń, które
 * na tę sumę się składają (rentals) - żeby klient widział, za co dokładnie płaci.
 */
public class DebtSummaryResponse {

    private String username;
    private BigDecimal totalDebt;
    private List<RentalDto> activeRentals;

    public DebtSummaryResponse() {
    }

    public DebtSummaryResponse(String username, BigDecimal totalDebt, List<RentalDto> activeRentals) {
        this.username = username;
        this.totalDebt = totalDebt;
        this.activeRentals = activeRentals;
    }

    public String getUsername() {
        return username;
    }

    public BigDecimal getTotalDebt() {
        return totalDebt;
    }

    public List<RentalDto> getActiveRentals() {
        return activeRentals;
    }
}

package pl.edu.utp.po.boardgames.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Encja "Wypożyczenie" z treści zadania: data zwrotu (dueDate) + status.
 *
 * Dodatkowo trzymamy:
 *  - borrowedAt   -> kiedy gra została wypożyczona (informacyjnie),
 *  - returnDate   -> kiedy FAKTYCZNIE oddano grę (null, dopóki gra nie wróci),
 *  - lateFeeAtReturn -> "zamrożona" kwota kary WYLICZONA W MOMENCIE zwrotu gry.
 *
 * Po co lateFeeAtReturn, skoro mamy już LateFeeCalculatorService?
 * Bo dla gry, która JUŻ wróciła, kara nie powinna się już zmieniać (np. rosnąć
 * z każdym kolejnym dniem) - musimy więc zapisać (zamrozić) tę kwotę w momencie
 * zwrotu. Dla gier, które są WCIĄŻ wypożyczone (status ACTIVE), kara jest liczona
 * "na żywo" przy każdym wyświetleniu strony (bo z każdym dniem rośnie).
 */
@Entity
@Table(name = "rentals")
public class Rental {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "game_id", nullable = false)
    private Game game;

    // Klient, który wypożyczył grę.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "borrower_id", nullable = false)
    private AppUser borrower;

    @Column(name = "borrowed_at", nullable = false)
    private LocalDate borrowedAt;

    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    // null dopóki gra nie zostanie zwrócona.
    @Column(name = "return_date")
    private LocalDate returnDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RentalStatus status = RentalStatus.ACTIVE;

    // null dopóki gra nie zostanie zwrócona - patrz opis klasy powyżej.
    @Column(name = "late_fee_at_return")
    private BigDecimal lateFeeAtReturn;

    public Rental() {
    }

    public Rental(Game game, AppUser borrower, LocalDate borrowedAt, LocalDate dueDate) {
        this.game = game;
        this.borrower = borrower;
        this.borrowedAt = borrowedAt;
        this.dueDate = dueDate;
        this.status = RentalStatus.ACTIVE;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public AppUser getBorrower() {
        return borrower;
    }

    public void setBorrower(AppUser borrower) {
        this.borrower = borrower;
    }

    public LocalDate getBorrowedAt() {
        return borrowedAt;
    }

    public void setBorrowedAt(LocalDate borrowedAt) {
        this.borrowedAt = borrowedAt;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public RentalStatus getStatus() {
        return status;
    }

    public void setStatus(RentalStatus status) {
        this.status = status;
    }

    public BigDecimal getLateFeeAtReturn() {
        return lateFeeAtReturn;
    }

    public void setLateFeeAtReturn(BigDecimal lateFeeAtReturn) {
        this.lateFeeAtReturn = lateFeeAtReturn;
    }
}

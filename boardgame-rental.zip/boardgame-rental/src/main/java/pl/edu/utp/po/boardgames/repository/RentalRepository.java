package pl.edu.utp.po.boardgames.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.edu.utp.po.boardgames.domain.Rental;
import pl.edu.utp.po.boardgames.domain.RentalStatus;

import java.util.List;

public interface RentalRepository extends JpaRepository<Rental, Long> {

    // Wypożyczenia JEDNEGO konkretnego klienta o danym statusie (np. wszystkie
    // AKTUALNIE wypożyczone przez niego gry) - realizuje wymaganie "Klient widzi
    // swój panel zadłużenia".
    List<Rental> findByBorrowerUsernameAndStatusOrderByDueDateAsc(String username, RentalStatus status);

    // Pełna historia wypożyczeń danego klienta (wypożyczone + już zwrócone).
    List<Rental> findByBorrowerUsernameOrderByBorrowedAtDesc(String username);

    // WSZYSTKIE aktualnie wypożyczone gry (dowolnego klienta) - potrzebne
    // pracownikowi, żeby mógł znaleźć i "zwrócić" dowolne wypożyczenie.
    List<Rental> findByStatusOrderByDueDateAsc(RentalStatus status);
}

package pl.edu.utp.po.boardgames.security;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import pl.edu.utp.po.boardgames.domain.AppUser;
import pl.edu.utp.po.boardgames.repository.AppUserRepository;

/**
 * Most pomiędzy naszą tabelą użytkowników (app_users) a mechanizmem logowania
 * Spring Security. Przy próbie logowania Spring Security automatycznie wywoła
 * loadUserByUsername(...), żeby sprawdzić dane logowania i rolę użytkownika.
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final AppUserRepository appUserRepository;

    public CustomUserDetailsService(AppUserRepository appUserRepository) {
        this.appUserRepository = appUserRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser appUser = appUserRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Nie znaleziono użytkownika: " + username));

        // .roles("EMPLOYEE") -> Spring Security sam doklei prefiks "ROLE_",
        // tworząc uprawnienie "ROLE_EMPLOYEE" (dokładnie to sprawdza hasRole("EMPLOYEE")).
        return User.builder()
                .username(appUser.getUsername())
                .password(appUser.getPassword()) // hasło już zahashowane w bazie (BCrypt)
                .roles(appUser.getRole())
                .build();
    }
}

package pl.edu.utp.po.boardgames.service;

import org.springframework.stereotype.Service;
import pl.edu.utp.po.boardgames.domain.GameCategory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * LateFeeCalculatorService = serce całego projektu: algorytm naliczający karę
 * za opóźnienie w zwrocie gry planszowej.
 *
 * ZASADA DZIAŁANIA (zgodnie z treścią zadania):
 *   kara = (liczba dni PO terminie zwrotu) * (stawka dzienna zależna od kategorii gry)
 *   np. "Biały kruk" = 10 zł/dzień, "Zwykła" = 2 zł/dzień.
 * Jeśli gra nie jest jeszcze spóźniona (zwrócona na czas / termin jeszcze nie minął),
 * kara wynosi 0 zł.
 *
 * WAŻNY SZCZEGÓŁ PROJEKTOWY - dlaczego metoda przyjmuje parametr `asOfDate`:
 * Dla gry, która JEST WCIĄŻ wypożyczona (nie została jeszcze zwrócona), musimy
 * jakoś ustalić "ile dni już minęło" - w prawdziwej aplikacji użylibyśmy po prostu
 * dzisiejszej daty (LocalDate.now()). Ale w TESTACH JEDNOSTKOWYCH nie chcemy zależeć
 * od tego, jaki dokładnie dzień jest "dzisiaj" na komputerze, na którym testy są
 * uruchamiane (inaczej testy byłyby niedeterministyczne). Dlatego "co uznajemy za
 * dzisiaj" jest jawnym parametrem metody - w testach podajemy konkretną, ustaloną
 * datę, a w prawdziwym działaniu aplikacji (patrz przeciążona metoda niżej) używamy
 * LocalDate.now().
 */
@Service
public class LateFeeCalculatorService {

    /**
     * Główna, w pełni deterministyczna wersja algorytmu (używana w testach).
     *
     * @param dueDate    termin, do którego gra miała zostać zwrócona
     * @param returnDate data FAKTYCZNEGO zwrotu gry, albo null, jeśli gra wciąż jest wypożyczona
     * @param asOfDate   data, którą traktujemy jako "dzisiaj" - używana TYLKO wtedy,
     *                   gdy returnDate == null (gra jeszcze nie wróciła)
     * @param category   kategoria gry, decyduje o stawce kary za dzień
     * @return naliczona kara (zaokrąglona do 2 miejsc po przecinku), 0.00 jeśli brak opóźnienia
     */
    public BigDecimal calculateLateFee(LocalDate dueDate, LocalDate returnDate, LocalDate asOfDate, GameCategory category) {

        if (dueDate == null) {
            throw new IllegalArgumentException("Termin zwrotu (dueDate) nie może być pusty");
        }
        if (category == null) {
            throw new IllegalArgumentException("Kategoria gry nie może być pusta");
        }

        // Jeśli gra została już zwrócona -> liczymy opóźnienie względem DATY ZWROTU
        // (kara jest "zamrożona" na zawsze na tym poziomie).
        // Jeśli gra jest WCIĄŻ wypożyczona -> liczymy opóźnienie względem "dzisiaj" (asOfDate)
        // - kara rośnie z każdym kolejnym dniem, dopóki gra nie zostanie zwrócona.
        LocalDate effectiveDate = (returnDate != null) ? returnDate : asOfDate;

        if (effectiveDate == null) {
            throw new IllegalArgumentException("Musisz podać returnDate albo asOfDate");
        }

        long daysLate = ChronoUnit.DAYS.between(dueDate, effectiveDate);

        // Brak opóźnienia (oddano na czas albo termin jeszcze nie minął) -> kara zerowa.
        if (daysLate <= 0) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }

        BigDecimal fee = category.getLateFeePerDay().multiply(BigDecimal.valueOf(daysLate));
        return fee.setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Wygodna "skrócona" wersja do użycia w prawdziwym działaniu aplikacji
     * (poza testami) - automatycznie używa dzisiejszej daty systemowej jako `asOfDate`.
     */
    public BigDecimal calculateLateFee(LocalDate dueDate, LocalDate returnDate, GameCategory category) {
        return calculateLateFee(dueDate, returnDate, LocalDate.now(), category);
    }

    /**
     * Pomocnicza metoda - zwraca samą liczbę dni opóźnienia (bez przeliczania na złotówki).
     * Przydatna np. do wyświetlenia w UI "spóźnione o X dni" obok kwoty kary.
     * Nigdy nie zwraca liczby ujemnej - brak opóźnienia to 0 dni, a nie liczba ujemna.
     */
    public long calculateDaysLate(LocalDate dueDate, LocalDate returnDate, LocalDate asOfDate) {
        LocalDate effectiveDate = (returnDate != null) ? returnDate : asOfDate;
        long daysLate = ChronoUnit.DAYS.between(dueDate, effectiveDate);
        return Math.max(daysLate, 0);
    }
}

package pl.edu.utp.po.boardgames.dto;

import pl.edu.utp.po.boardgames.domain.RentalStatus;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * DTO zwracane klientowi/pracownikowi - opisuje JEDNO wypożyczenie razem
 * z wyliczoną (na żywo, dla aktywnych wypożyczeń) liczbą dni opóźnienia i karą.
 *
 * Nie zwracamy tu bezpośrednio encji Rental, żeby:
 *  - nie wystawiać na zewnątrz całego obiektu AppUser (z hasłem itd.),
 *  - móc dołożyć POLICZONE "w locie" (nie zapisane w bazie) wartości:
 *    daysLate oraz currentFee.
 */
public class RentalDto {

    private Long id;
    private String gameTitle;
    private String gameCategory;      // np. "COMMON" - surowa nazwa stałej enuma
    private String gameCategoryLabel; // np. "Zwykła" - ładna nazwa do wyświetlenia w UI
    private String borrowerUsername;
    private LocalDate borrowedAt;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private RentalStatus status;
    private long daysLate;
    private BigDecimal currentFee;

    public RentalDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGameTitle() {
        return gameTitle;
    }

    public void setGameTitle(String gameTitle) {
        this.gameTitle = gameTitle;
    }

    public String getGameCategory() {
        return gameCategory;
    }

    public void setGameCategory(String gameCategory) {
        this.gameCategory = gameCategory;
    }

    public String getGameCategoryLabel() {
        return gameCategoryLabel;
    }

    public void setGameCategoryLabel(String gameCategoryLabel) {
        this.gameCategoryLabel = gameCategoryLabel;
    }

    public String getBorrowerUsername() {
        return borrowerUsername;
    }

    public void setBorrowerUsername(String borrowerUsername) {
        this.borrowerUsername = borrowerUsername;
    }

    public LocalDate getBorrowedAt() {
        return borrowedAt;
    }

    public void setBorrowedAt(LocalDate borrowedAt) {
        this.borrowedAt = borrowedAt;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public RentalStatus getStatus() {
        return status;
    }

    public void setStatus(RentalStatus status) {
        this.status = status;
    }

    public long getDaysLate() {
        return daysLate;
    }

    public void setDaysLate(long daysLate) {
        this.daysLate = daysLate;
    }

    public BigDecimal getCurrentFee() {
        return currentFee;
    }

    public void setCurrentFee(BigDecimal currentFee) {
        this.currentFee = currentFee;
    }
}

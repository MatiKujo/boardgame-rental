package pl.edu.utp.po.boardgames.domain;

import java.math.BigDecimal;

/**
 * Enum kategorii (rzadkości) gry planszowej.
 *
 * To jest KLUCZOWY element algorytmu naliczania kar: każda kategoria ma
 * WBUDOWANĄ (na stałe zaszytą) stawkę kary za jeden dzień opóźnienia zwrotu.
 * Dzięki temu, że stawka jest polem enuma (a nie np. osobną kolumną w bazie,
 * którą ktoś mógłby przez pomyłkę źle wpisać), mamy pewność, że dla danej
 * kategorii stawka jest zawsze taka sama i zdefiniowana w jednym miejscu.
 *
 * Wartości zgodnie z treścią zadania:
 *   - "Biały kruk" (najrzadsza, najcenniejsza gra) -> 10 zł/dzień
 *   - "Zwykła" -> 2 zł/dzień
 * Dodatkowo dodajemy kategorię pośrednią "Rzadka" -> 5 zł/dzień, żeby system
 * był trochę bardziej rozbudowany (typowe dla systemów wypożyczalni: więcej
 * niż 2 poziomy rzadkości).
 */
public enum GameCategory {

    COMMON("Zwykła", new BigDecimal("2.00")),
    UNCOMMON("Rzadka", new BigDecimal("5.00")),
    RARE("Biały kruk", new BigDecimal("10.00"));

    // Nazwa wyświetlana użytkownikowi (po polsku) - enum "z natury" ma tylko nazwę
    // stałej w Javie (np. RARE), a chcemy też ładną etykietę do pokazania w UI.
    private final String displayName;

    // Stawka kary za KAŻDY dzień opóźnienia zwrotu gry tej kategorii.
    private final BigDecimal lateFeePerDay;

    // Konstruktor enuma - w Javie enumy MOGĄ mieć pola i konstruktor, dokładnie
    // tak jak zwykłe klasy. Konstruktor enuma jest zawsze prywatny (nie da się
    // go wywołać z zewnątrz przez "new" - stałe enuma są tworzone automatycznie).
    GameCategory(String displayName, BigDecimal lateFeePerDay) {
        this.displayName = displayName;
        this.lateFeePerDay = lateFeePerDay;
    }

    public String getDisplayName() {
        return displayName;
    }

    public BigDecimal getLateFeePerDay() {
        return lateFeePerDay;
    }
}

package pl.edu.utp.po.boardgames.dto;

import jakarta.validation.constraints.NotNull;

/**
 * DTO danych przesłanych przez klienta przy wypożyczaniu gry.
 * Klient podaje TYLKO id gry - termin zwrotu (dueDate) system ustala sam,
 * jako standardowy okres wypożyczenia (patrz RentalService.STANDARD_LOAN_DAYS).
 */
public class BorrowRequest {

    @NotNull(message = "Musisz wybrać grę")
    private Long gameId;

    public BorrowRequest() {
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }
}

package pl.edu.utp.po.boardgames.domain;

/**
 * Status wypożyczenia gry.
 * ACTIVE   - gra jest aktualnie u klienta (nie została jeszcze zwrócona).
 * RETURNED - gra została zwrócona (przez pracownika - patrz RentalService.returnGame).
 */
public enum RentalStatus {
    ACTIVE,
    RETURNED
}

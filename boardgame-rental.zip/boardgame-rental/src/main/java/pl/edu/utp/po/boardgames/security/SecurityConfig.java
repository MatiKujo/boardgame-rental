package pl.edu.utp.po.boardgames.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Centralna konfiguracja bezpieczeństwa.
 *
 * ZASADY DOSTĘPU (zgodnie z treścią zadania):
 *  - zalogowany klient (CUSTOMER lub EMPLOYEE) -> widzi TYLKO swój panel
 *    zadłużenia (GET /api/debts/my, strona /my-rentals),
 *  - TYLKO pracownik (EMPLOYEE) -> może oznaczyć DOWOLNĄ grę jako zwróconą
 *    (POST /api/rentals/{id}/return) i widzi listę WSZYSTKICH aktywnych wypożyczeń.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/css/**", "/js/**", "/webjars/**").permitAll()
                        .requestMatchers("/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**").permitAll()
                        // Konsola H2 - TYLKO do nauki/developmentu.
                        .requestMatchers("/h2-console/**").permitAll()
                        .requestMatchers("/login").permitAll()

                        // Zwrot gry oraz podgląd WSZYSTKICH aktywnych wypożyczeń - TYLKO pracownik.
                        .requestMatchers("/api/rentals/*/return").hasRole("EMPLOYEE")
                        .requestMatchers(HttpMethod.GET, "/api/rentals/active").hasRole("EMPLOYEE")
                        .requestMatchers("/employee/**").hasRole("EMPLOYEE")

                        // Zadłużenie i wypożyczenia - dowolny zalogowany klient (widzi TYLKO swoje,
                        // bo login zawsze bierzemy z sesji - patrz kontrolery REST).
                        .requestMatchers("/api/debts/**").authenticated()
                        .requestMatchers("/api/rentals/**").authenticated()

                        // Reszta stron webowych (moje wypożyczenia, wypożycz grę) wymaga logowania.
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .defaultSuccessUrl("/my-rentals", true)
                        .permitAll()
                )
                .httpBasic(Customizer.withDefaults())
                .csrf(csrf -> csrf.ignoringRequestMatchers("/api/**", "/h2-console/**"))
                .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()))
                .logout(logout -> logout
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

        return http.build();
    }
}

package pl.edu.utp.po.boardgames.service;

import org.springframework.stereotype.Service;
import pl.edu.utp.po.boardgames.domain.AppUser;
import pl.edu.utp.po.boardgames.domain.Game;
import pl.edu.utp.po.boardgames.domain.Rental;
import pl.edu.utp.po.boardgames.domain.RentalStatus;
import pl.edu.utp.po.boardgames.dto.BorrowRequest;
import pl.edu.utp.po.boardgames.dto.DebtSummaryResponse;
import pl.edu.utp.po.boardgames.dto.RentalDto;
import pl.edu.utp.po.boardgames.repository.AppUserRepository;
import pl.edu.utp.po.boardgames.repository.GameRepository;
import pl.edu.utp.po.boardgames.repository.RentalRepository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Serwis "spinający w całość" cały cykl życia wypożyczenia gry:
 * wypożyczenie -> (ewentualne opóźnienie i naliczanie kary "na żywo") -> zwrot.
 *
 * Korzysta z LateFeeCalculatorService do wszystkich wyliczeń finansowych -
 * ten serwis SAM w sobie nie zawiera żadnej logiki liczenia kar, tylko
 * "orkiestruje" dane (pobiera z bazy, woła kalkulator, zapisuje wynik).
 */
@Service
public class RentalService {

    // Standardowy okres wypożyczenia gry - używany przy zakładaniu nowego wypożyczenia.
    private static final int STANDARD_LOAN_DAYS = 14;

    private final RentalRepository rentalRepository;
    private final GameRepository gameRepository;
    private final AppUserRepository appUserRepository;
    private final LateFeeCalculatorService lateFeeCalculatorService;

    public RentalService(RentalRepository rentalRepository,
                          GameRepository gameRepository,
                          AppUserRepository appUserRepository,
                          LateFeeCalculatorService lateFeeCalculatorService) {
        this.rentalRepository = rentalRepository;
        this.gameRepository = gameRepository;
        this.appUserRepository = appUserRepository;
        this.lateFeeCalculatorService = lateFeeCalculatorService;
    }

    /** Lista gier dostępnych aktualnie do wypożyczenia (bez aktywnego wypożyczenia). */
    public List<Game> getAvailableGames() {
        return gameRepository.findAvailableGames();
    }

    /**
     * Wypożycza grę dla podanego klienta. Termin zwrotu ustalany jest automatycznie
     * jako "dzisiaj + STANDARD_LOAN_DAYS dni". Zwraca od razu gotowe DTO (z policzoną,
     * na starcie zerową, karą) - dzięki temu wywołujący kontroler nie musi robić
     * drugiego zapytania do bazy, żeby zbudować odpowiedź.
     */
    public RentalDto borrowGame(String username, BorrowRequest request) {
        Game game = gameRepository.findById(request.getGameId())
                .orElseThrow(() -> new NoSuchElementException("Nie znaleziono gry o id " + request.getGameId()));

        // Sprawdź, czy ta gra nie jest już aktualnie u kogoś innego wypożyczona.
        boolean alreadyBorrowed = rentalRepository.findByStatusOrderByDueDateAsc(RentalStatus.ACTIVE).stream()
                .anyMatch(r -> r.getGame().getId().equals(game.getId()));
        if (alreadyBorrowed) {
            throw new IllegalStateException("Ta gra jest już aktualnie wypożyczona przez innego klienta");
        }

        AppUser borrower = appUserRepository.findByUsername(username)
                .orElseThrow(() -> new NoSuchElementException("Nie znaleziono użytkownika " + username));

        LocalDate today = LocalDate.now();
        Rental rental = new Rental(game, borrower, today, today.plusDays(STANDARD_LOAN_DAYS));

        Rental saved = rentalRepository.save(rental);
        return toDto(saved);
    }

    /**
     * Zwraca listę AKTUALNIE wypożyczonych gier danego klienta, razem z "na żywo"
     * wyliczoną liczbą dni opóźnienia i karą - dokładnie to, co ma pokazywać
     * "Widok wypożyczonych aktualnie gier przez użytkownika z informacją
     * o ewentualnych karach" z treści zadania.
     */
    public List<RentalDto> getActiveRentalsForUser(String username) {
        return rentalRepository.findByBorrowerUsernameAndStatusOrderByDueDateAsc(username, RentalStatus.ACTIVE)
                .stream()
                .map(this::toDto)
                .toList();
    }

    /** Pełna historia wypożyczeń klienta (wypożyczone + już zwrócone). */
    public List<RentalDto> getRentalHistoryForUser(String username) {
        return rentalRepository.findByBorrowerUsernameOrderByBorrowedAtDesc(username)
                .stream()
                .map(this::toDto)
                .toList();
    }

    /**
     * GŁÓWNA metoda realizująca wymaganie: "Endpoint GET zwracający aktualne
     * zadłużenie użytkownika". Sumuje kary ze WSZYSTKICH aktywnych (jeszcze
     * niezwróconych) wypożyczeń danego klienta.
     */
    public DebtSummaryResponse getDebtSummary(String username) {
        List<RentalDto> activeRentals = getActiveRentalsForUser(username);

        BigDecimal totalDebt = activeRentals.stream()
                .map(RentalDto::getCurrentFee)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return new DebtSummaryResponse(username, totalDebt, activeRentals);
    }

    /** WSZYSTKIE aktualnie wypożyczone gry (dowolnego klienta) - widok pracownika. */
    public List<RentalDto> getAllActiveRentals() {
        return rentalRepository.findByStatusOrderByDueDateAsc(RentalStatus.ACTIVE)
                .stream()
                .map(this::toDto)
                .toList();
    }

    /**
     * Oznacza wypożyczenie jako zwrócone: ustawia returnDate na dzisiaj, przelicza
     * i "zamraża" ostateczną karę (lateFeeAtReturn), zmienia status na RETURNED.
     *
     * UWAGA: to, że tę metodę wolno wywołać TYLKO pracownikowi (rola EMPLOYEE),
     * jest wymuszone na poziomie SecurityConfig / kontrolera, a nie tutaj -
     * ta metoda skupia się wyłącznie na samej logice zwrotu gry.
     */
    public RentalDto returnGame(Long rentalId) {
        Rental rental = rentalRepository.findById(rentalId)
                .orElseThrow(() -> new NoSuchElementException("Nie znaleziono wypożyczenia o id " + rentalId));

        if (rental.getStatus() == RentalStatus.RETURNED) {
            throw new IllegalStateException("Ta gra została już wcześniej zwrócona");
        }

        LocalDate today = LocalDate.now();
        BigDecimal finalFee = lateFeeCalculatorService.calculateLateFee(
                rental.getDueDate(), today, rental.getGame().getCategory());

        rental.setReturnDate(today);
        rental.setLateFeeAtReturn(finalFee);
        rental.setStatus(RentalStatus.RETURNED);

        Rental saved = rentalRepository.save(rental);
        return toDto(saved);
    }

    /** Zamienia encję Rental na DTO, doliczając "na żywo" dni opóźnienia i karę. */
    private RentalDto toDto(Rental rental) {
        RentalDto dto = new RentalDto();
        dto.setId(rental.getId());
        dto.setGameTitle(rental.getGame().getTitle());
        dto.setGameCategory(rental.getGame().getCategory().name());
        dto.setGameCategoryLabel(rental.getGame().getCategory().getDisplayName());
        dto.setBorrowerUsername(rental.getBorrower().getUsername());
        dto.setBorrowedAt(rental.getBorrowedAt());
        dto.setDueDate(rental.getDueDate());
        dto.setReturnDate(rental.getReturnDate());
        dto.setStatus(rental.getStatus());

        if (rental.getStatus() == RentalStatus.RETURNED) {
            // Gra już wróciła - używamy "zamrożonej" kary zapisanej w momencie zwrotu,
            // NIE przeliczamy jej ponownie (bo od tamtej pory kara już nie rośnie).
            long daysLate = lateFeeCalculatorService.calculateDaysLate(
                    rental.getDueDate(), rental.getReturnDate(), LocalDate.now());
            dto.setDaysLate(daysLate);
            dto.setCurrentFee(rental.getLateFeeAtReturn());
        } else {
            // Gra wciąż wypożyczona - liczymy karę "na żywo" względem dzisiejszej daty.
            LocalDate today = LocalDate.now();
            long daysLate = lateFeeCalculatorService.calculateDaysLate(rental.getDueDate(), null, today);
            BigDecimal fee = lateFeeCalculatorService.calculateLateFee(
                    rental.getDueDate(), null, today, rental.getGame().getCategory());
            dto.setDaysLate(daysLate);
            dto.setCurrentFee(fee);
        }

        return dto;
    }
}

package pl.edu.utp.po.boardgames.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import pl.edu.utp.po.boardgames.domain.Game;

import java.util.List;

public interface GameRepository extends JpaRepository<Game, Long> {

    /**
     * Zwraca gry, które NIE mają obecnie żadnego AKTYWNEGO wypożyczenia
     * (czyli można je pożyczyć). Używane na stronie "Dostępne gry".
     */
    @Query("""
            SELECT g FROM Game g
            WHERE g.id NOT IN (
                SELECT r.game.id FROM Rental r
                WHERE r.status = pl.edu.utp.po.boardgames.domain.RentalStatus.ACTIVE
            )
            """)
    List<Game> findAvailableGames();
}

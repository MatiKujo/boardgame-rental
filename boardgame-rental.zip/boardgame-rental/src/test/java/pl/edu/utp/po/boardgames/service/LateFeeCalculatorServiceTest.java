package pl.edu.utp.po.boardgames.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pl.edu.utp.po.boardgames.domain.GameCategory;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Testy jednostkowe dla LateFeeCalculatorService - algorytmu naliczającego karę
 * za opóźnienie w zwrocie gry planszowej (wymaganie z treści zadania:
 * "Testy jednostkowe kalkulatora kar na podstawie różnych dat i kategorii gier").
 *
 * Uruchomienie: `mvn test` albo prawy klik na klasę w IDE -> Run.
 *
 * WAŻNE: we wszystkich testach PODAJEMY jawnie konkretne daty (nigdy nie polegamy
 * na LocalDate.now()) - dzięki temu testy są w 100% deterministyczne i będą dawać
 * ten sam wynik niezależnie od tego, kiedy je uruchomisz.
 */
class LateFeeCalculatorServiceTest {

    private final LateFeeCalculatorService calculator = new LateFeeCalculatorService();

    // Stała data odniesienia używana w testach jako "punkt zaczepienia" - łatwo
    // liczyć różnice w dniach, patrząc na te same, stałe daty w każdym teście.
    private static final LocalDate DUE_DATE = LocalDate.of(2024, 6, 10);

    @Test
    @DisplayName("Gra zwrócona DOKŁADNIE w terminie -> kara 0 zł")
    void returnedExactlyOnDueDate_zeroFee() {
        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, DUE_DATE, DUE_DATE, GameCategory.COMMON);

        assertThat(fee).isEqualByComparingTo("0.00");
    }

    @Test
    @DisplayName("Gra zwrócona PRZED terminem -> kara 0 zł (nie ma 'ujemnej' kary)")
    void returnedBeforeDueDate_zeroFee() {
        LocalDate returnedEarly = DUE_DATE.minusDays(3);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, returnedEarly, DUE_DATE, GameCategory.RARE);

        assertThat(fee).isEqualByComparingTo("0.00");
    }

    @Test
    @DisplayName("Kategoria COMMON ('Zwykła'), 1 dzień opóźnienia -> 2,00 zł")
    void commonCategory_oneDayLate() {
        LocalDate returnDate = DUE_DATE.plusDays(1);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, returnDate, DUE_DATE, GameCategory.COMMON);

        assertThat(fee).isEqualByComparingTo("2.00");
    }

    @Test
    @DisplayName("Kategoria COMMON ('Zwykła'), 5 dni opóźnienia -> 10,00 zł")
    void commonCategory_fiveDaysLate() {
        LocalDate returnDate = DUE_DATE.plusDays(5);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, returnDate, DUE_DATE, GameCategory.COMMON);

        assertThat(fee).isEqualByComparingTo("10.00");
    }

    @Test
    @DisplayName("Kategoria UNCOMMON ('Rzadka'), 4 dni opóźnienia -> 20,00 zł")
    void uncommonCategory_fourDaysLate() {
        LocalDate returnDate = DUE_DATE.plusDays(4);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, returnDate, DUE_DATE, GameCategory.UNCOMMON);

        assertThat(fee).isEqualByComparingTo("20.00");
    }

    @Test
    @DisplayName("Kategoria RARE ('Biały kruk'), 1 dzień opóźnienia -> 10,00 zł")
    void rareCategory_oneDayLate() {
        LocalDate returnDate = DUE_DATE.plusDays(1);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, returnDate, DUE_DATE, GameCategory.RARE);

        assertThat(fee).isEqualByComparingTo("10.00");
    }

    @Test
    @DisplayName("Kategoria RARE ('Biały kruk'), 6 dni opóźnienia -> 60,00 zł")
    void rareCategory_sixDaysLate() {
        LocalDate returnDate = DUE_DATE.plusDays(6);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, returnDate, DUE_DATE, GameCategory.RARE);

        assertThat(fee).isEqualByComparingTo("60.00");
    }

    @Test
    @DisplayName("Gra WCIĄŻ wypożyczona (returnDate = null), termin już minął -> kara liczona względem asOfDate")
    void stillBorrowed_feeCalculatedAgainstAsOfDate() {
        // returnDate = null -> gra jeszcze nie wróciła, więc liczymy karę "na dziś" (asOfDate)
        LocalDate asOfDate = DUE_DATE.plusDays(3);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, null, asOfDate, GameCategory.COMMON);

        assertThat(fee).isEqualByComparingTo("6.00"); // 3 dni * 2 zł
    }

    @Test
    @DisplayName("Gra WCIĄŻ wypożyczona, termin JESZCZE NIE minął -> kara 0 zł")
    void stillBorrowed_notYetDue_zeroFee() {
        LocalDate asOfDate = DUE_DATE.minusDays(2); // dzisiaj jest jeszcze PRZED terminem zwrotu

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, null, asOfDate, GameCategory.RARE);

        assertThat(fee).isEqualByComparingTo("0.00");
    }

    @Test
    @DisplayName("Wynik jest zawsze zaokrąglony do 2 miejsc po przecinku")
    void resultIsRoundedToTwoDecimalPlaces() {
        LocalDate returnDate = DUE_DATE.plusDays(2);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, returnDate, DUE_DATE, GameCategory.UNCOMMON);

        assertThat(fee.scale()).isEqualTo(2);
        assertThat(fee).isEqualByComparingTo("10.00"); // 2 dni * 5 zł
    }

    @Test
    @DisplayName("calculateDaysLate zwraca poprawną liczbę dni opóźnienia, nigdy ujemną")
    void calculateDaysLate_neverNegative() {
        assertThat(calculator.calculateDaysLate(DUE_DATE, DUE_DATE.plusDays(4), DUE_DATE)).isEqualTo(4);
        assertThat(calculator.calculateDaysLate(DUE_DATE, DUE_DATE.minusDays(2), DUE_DATE)).isEqualTo(0);
        assertThat(calculator.calculateDaysLate(DUE_DATE, null, DUE_DATE.plusDays(7))).isEqualTo(7);
    }

    @Test
    @DisplayName("Brak podanego terminu zwrotu (dueDate = null) -> wyjątek IllegalArgumentException")
    void nullDueDate_throwsException() {
        assertThatThrownBy(() ->
                calculator.calculateLateFee(null, DUE_DATE, DUE_DATE, GameCategory.COMMON))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("Brak podanej kategorii gry -> wyjątek IllegalArgumentException")
    void nullCategory_throwsException() {
        assertThatThrownBy(() ->
                calculator.calculateLateFee(DUE_DATE, DUE_DATE.plusDays(1), DUE_DATE, null))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("Przeciążona metoda bez asOfDate (używająca LocalDate.now()) działa dla gry już zwróconej")
    void overloadedMethod_worksForReturnedGame() {
        // Gdy returnDate jest podane, metoda w ogóle nie sięga po LocalDate.now(),
        // więc ten test JEST deterministyczny mimo użycia "skróconej" wersji metody.
        LocalDate returnDate = DUE_DATE.plusDays(3);

        BigDecimal fee = calculator.calculateLateFee(DUE_DATE, returnDate, GameCategory.RARE);

        assertThat(fee).isEqualByComparingTo("30.00");
    }
}

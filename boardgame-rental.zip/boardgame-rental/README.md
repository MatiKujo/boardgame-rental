# Wypożyczalnia gier planszowych - Naliczanie kar

Projekt zaliczeniowy: Spring Boot (Java) + Thymeleaf (UI) + REST API + Swagger +
Spring Security + testy jednostkowe (JUnit 5).

## Co jest w środku (spełnione wymagania)

- **Baza danych**: `Game` (tytuł, kategoria rzadkości), `Rental` (Wypożyczenie: data
  zwrotu, status) + dodatkowo `AppUser` - baza H2 "w pamięci", zasilana danymi
  startowymi automatycznie przy uruchomieniu (`DataInitializer`), w tym JEDNYM
  celowo przeterminowanym wypożyczeniem, żeby od razu było widać działającą karę.
- **Webowe UI (Thymeleaf)**: `/my-rentals` - GŁÓWNY widok: aktualnie wypożyczone gry
  klienta wraz z naliczoną karą, `/games` - dostępne gry + wypożyczanie,
  `/employee/rentals` - panel pracownika (zwrot dowolnej gry).
- **Algorytm**: `LateFeeCalculatorService` - kara = liczba dni po terminie * stawka
  dzienna zależna od kategorii ("Biały kruk" = 10 zł/dzień, "Zwykła" = 2 zł/dzień,
  dodatkowo "Rzadka" = 5 zł/dzień).
- **REST + Swagger**: `GET /api/debts/my` - aktualne zadłużenie zalogowanego klienta.
  Dokumentacja pod `/swagger-ui.html`.
- **Security**: klient (rola CUSTOMER) widzi TYLKO swój panel zadłużenia, pracownik
  (rola EMPLOYEE) może oznaczyć DOWOLNĄ grę jako zwróconą.
- **Testy**: `LateFeeCalculatorServiceTest` - komplet unit testów kalkulatora kar
  dla różnych dat i kategorii gier.

## Wymagania do uruchomienia

- **Java 17** lub nowsza
- **Maven** - lub po prostu zaimportuj folder jako projekt Maven w IntelliJ IDEA / Eclipse.

## Jak uruchomić

### Opcja A: z terminala (Maven)
```bash
mvn spring-boot:run
```

### Opcja B: z IDE
1. Otwórz folder `boardgame-rental` jako projekt Maven (File -> Open -> wskaż `pom.xml`).
2. Poczekaj, aż IDE pobierze zależności.
3. Kliknij prawym na `BoardGameRentalApplication.java` -> **Run**.

### Opcja C: zbuduj gotowy .jar
```bash
mvn clean package
java -jar target/boardgame-rental.jar
```

Aplikacja wystartuje na porcie **8080**.

## Adresy po uruchomieniu

| Co | Adres |
|---|---|
| Moje wypożyczenia (panel klienta + kary) | http://localhost:8080/my-rentals |
| Dostępne gry / wypożyczanie | http://localhost:8080/games |
| Panel pracownika (zwrot gry) | http://localhost:8080/employee/rentals |
| Dokumentacja API (Swagger) | http://localhost:8080/swagger-ui.html |
| Konsola bazy danych H2 | http://localhost:8080/h2-console |

**Dane logowania do H2 console**: JDBC URL = `jdbc:h2:mem:boardgamesdb`, user = `sa`, hasło = puste.

## Konta testowe (tworzone automatycznie przy starcie)

| Login | Hasło | Rola |
|---|---|---|
| `user` | `user123` | CUSTOMER (klient - ma już jedną przeterminowaną grę: "Gloomhaven", kara 60 zł) |
| `ewa` | `ewa12345` | CUSTOMER (drugi klient, też ma przeterminowaną grę, kara 10 zł) |
| `pracownik` | `pracownik123` | EMPLOYEE (jedyna rola mogąca zwracać gry w systemie) |

Zaloguj się jako `user`, wejdź na `/my-rentals` - od razu zobaczysz naliczoną karę
60,00 zł za grę "Gloomhaven" (kategoria "Biały kruk", 6 dni opóźnienia * 10 zł).

## Główne endpointy REST

- `GET /api/games/available` - lista gier dostępnych do wypożyczenia
- `POST /api/rentals` - wypożycz grę: `{ "gameId": 1 }` (zalogowany klient, termin = +14 dni)
- `GET /api/rentals/my` - lista własnych aktywnych wypożyczeń z naliczonymi karami
- `GET /api/debts/my` - **GŁÓWNY endpoint**: aktualne zadłużenie zalogowanego klienta
  (suma kar + lista wypożyczeń)
- `GET /api/rentals/active` - lista WSZYSTKICH aktywnych wypożyczeń (**tylko EMPLOYEE**)
- `POST /api/rentals/{id}/return` - oznacz grę jako zwróconą (**tylko EMPLOYEE**)

Najwygodniej przetestować w Swagger UI (`/swagger-ui.html`) - kliknij "Authorize"
i podaj login/hasło z tabeli powyżej (Basic Auth).

## Algorytm naliczania kar (LateFeeCalculatorService)

1. Ustal datę, względem której liczymy opóźnienie:
   - jeśli gra JUŻ wróciła -> data faktycznego zwrotu (kara jest wtedy "zamrożona"
     na zawsze na tym poziomie, zapisana w polu `Rental.lateFeeAtReturn`),
   - jeśli gra WCIĄŻ jest wypożyczona -> dzisiejsza data (kara rośnie codziennie,
     wyliczana "na żywo" przy każdym wyświetleniu strony).
2. Licz dni opóźnienia = ta data MINUS termin zwrotu. Jeśli wynik <= 0 -> kara 0 zł.
3. Kara = liczba dni opóźnienia * stawka dzienna danej kategorii gry
   (`GameCategory.getLateFeePerDay()`).
4. Wynik zaokrąglany do 2 miejsc po przecinku.

Pełny komplet testów: `src/test/java/pl/edu/utp/po/boardgames/service/LateFeeCalculatorServiceTest.java`

Testy celowo NIGDY nie polegają na `LocalDate.now()` - zawsze podają jawne, ustalone
daty (parametr `asOfDate`), dzięki czemu wynik testów nie zależy od tego, kiedy je
uruchomisz.

## Jak uruchomić testy

```bash
mvn test
```

## Struktura projektu (najważniejsze pakiety)

```
pl.edu.utp.po.boardgames
├── domain          -> encje bazodanowe (Game, GameCategory, Rental, RentalStatus, AppUser)
├── repository       -> interfejsy Spring Data JPA
├── service          -> logika biznesowa (LateFeeCalculatorService - algorytm!, RentalService)
├── security         -> konfiguracja Spring Security + UserDetailsService
├── web              -> kontrolery REST (@RestController) + obsługa błędów
├── controller       -> kontroler MVC (Thymeleaf, strony HTML)
├── dto              -> obiekty transferu danych (request/response)
└── config           -> DataInitializer (dane startowe, w tym przeterminowane wypożyczenie)
```

## Uwaga

Każdy plik `.java` jest bardzo obficie skomentowany po polsku - specjalnie po to,
żeby dało się z niego uczyć / bronić projektu na egzaminie bez wcześniejszej dobrej
znajomości Javy i Springa. Zacznij czytanie od `LateFeeCalculatorService.java`
(serce algorytmu) i `SecurityConfig.java` (reguły dostępu klient/pracownik).
